#!/usr/bin/env python
# -*- coding: utf_8 -*-
"""
 Modbus TestKit: Implementation of Modbus protocol in python
"""

import modbus_tk
import modbus_tk.defines as cst
from modbus_tk import modbus_tcp


def main():
    """main"""
    logger = modbus_tk.utils.create_logger("console")

    try:
        master_14 = modbus_tcp.TcpMaster(host='192.168.1.14')
        master_14.set_timeout(5.0)
        logger.info("Connected to 192.168.1.14")
        #Connect to other slave(s)
        
        #add queries to follow the assignment pdf, example queries have been provided for you 
        logger.info(master_11.execute(14, cst.READ_COILS, 0, 2))
        logger.info(master_11.execute(14, cst.WRITE_MULTIPLE_COILS, 0, output_value=[1, 1]))

    except modbus_tk.modbus.ModbusError as exc:
        logger.error("%s- Code=%d", exc, exc.get_exception_code())

if __name__ == "__main__":
    main()
