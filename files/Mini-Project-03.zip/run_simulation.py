#!/usr/bin/python

#################################################################################
# ECE 8813: Cyber Physical Systems Security
# Mini Project 3
##################################################################################

from mininet.topo import Topo
from mininet.net import Mininet
from mininet.link import TCLink
from mininet.util import dumpNodeConnections
from mininet.node import CPULimitedHost
from mininet.log import setLogLevel
from mininet.cli import CLI

import sys

# Topology for Mini-Project 3: Industrial Control System Topology
class ICSTopo(Topo):
    def __init__(self, cpu=.1, max_queue_size=None, **params):

        # Initialize topo
        Topo.__init__(self, **params)

        # Host and link configuration
        hostConfig = {'cpu': cpu}
        linkConfig = {'bw': 10, 'delay': '1ms', 'loss': 0,
                   'max_queue_size': max_queue_size }

        # Hosts and switches
        s1 = self.addSwitch('s1')
        h1 = self.addHost('h1', **hostConfig)
        h11 = self.addHost('h11', **hostConfig)
        #Add your hosts
        

        # Wire Network
        self.addLink(h1, s1, **linkConfig)
        self.addLink(h11, s1, **linkConfig)
		#Add your links

# Creates an instance of the topology defined above, starts it, and either starts the 
# student code or launches the command Line interface (CLI)
def runSimulation():    
    # Instantiate the network
    topo = ICSTopo()
    net = Mininet(topo=topo, host=CPULimitedHost, link=TCLink)
    
    # Set IP addresses
    h13 = net.get('h13')
    h13.setIP('192.168.1.13', 24)

    h14 = net.get('h14')
    h14.setIP('192.168.1.14')

    #set ip addresses of your other hosts
    

    # Start Mininet
    net.start()
      
    
    # Test Network connectivity
    print "Testing network connectivity"
    #Add command to ping all your hosts to test connectivity

    # If the parameter '--clean' is specified, start CLI without any slaves running
    if len(sys.argv) > 1 and sys.argv[1] == "--clean":
        print "Starting the CLI - Clean"
        CLI(net)
    # Otherwise, run the simulation in automatic mode: Starts the slaves automatically
    else:
        print "Running simulation - starting slaves automatically"
        
        h11.cmd('python ./tcp_slave.py 11 > /dev/null 2>&1 &')
        # Start any other slave(s)
        

        # Start the master device with the following command at the CLI:
        # h13 python ./tcp_master.py
        CLI(net)                    
    
    net.stop()

# Main Method:  Sets appropriate log level and initiates the simulation.
if __name__ == '__main__':
    setLogLevel('output')
    runSimulation()
